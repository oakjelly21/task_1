package com.example.myapplication;

import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.graphics.Color;
import android.media.Image;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    EditText ageinpfield;
    Button enterbutton;
    ConstraintLayout bg;
    int age;
    Random  random  = new Random();
    int dec_age = random.nextInt(99)+1;
    int triescounter;
    final int imgindex = random.nextInt(9);
    int img[] = {R.drawable.img1,R.drawable.img2,R.drawable.img3,R.drawable.img4,R.drawable.img5,R.drawable.img6,R.drawable.img7,R.drawable.img8,R.drawable.img9,R.drawable.img10};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bg = findViewById(R.id.bg);

        bg.setBackgroundResource(img[imgindex]);
        ageinpfield = findViewById(R.id.ageinpfield);
        enterbutton  =  findViewById(R.id.enterbutton);
        enterbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              age = Integer.parseInt(ageinpfield.getText().toString());
              if(age < dec_age) {
                  Toast.makeText(MainActivity.this, "go higher", Toast.LENGTH_SHORT).show();
                  //bg.setBackgroundColor(Color.RED);
                  //manageBlinkEffect();
                  //bg.setBackgroundResource(img[imgindex]);
                  triescounter++;
              }
              else if (age>dec_age) {
                  Toast.makeText(MainActivity.this, "go lower", Toast.LENGTH_SHORT).show();
                  //bg.setBackgroundColor(Color.RED);
                  //manageBlinkEffect();
                  //bg.setBackgroundResource(img[imgindex]);
                  triescounter++;
              }
              else {
                  Toast.makeText(MainActivity.this, "You got it ", Toast.LENGTH_SHORT).show();
                  //Intent intent = new Intent(this, DisplayActivity.class);
                  launchScorePage(++triescounter);

              }
            }
        });
    }
    public void launchScorePage (int count)
    {
        Intent intent = new Intent(this, DisplayActivity.class);
        intent.putExtra("1001", ""+count);
        startActivity(intent);
    }
}
