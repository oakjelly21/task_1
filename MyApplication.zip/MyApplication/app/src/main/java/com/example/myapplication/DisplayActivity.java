package com.example.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;



public class DisplayActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);
        Intent intent = getIntent();
        //int tries = Integer.parseInt(intent.getStringExtra("1001"));
        String s = intent.getStringExtra("1001");
        TextView scoredisplay = findViewById(R.id.score);
        //String  message = "you guessed it in"+tries+"tries";
        scoredisplay.setText("You guessed it in " + s + " tries");
        Button tryagain = findViewById(R.id.tryagain);
        tryagain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launchguesspage();
            }

        });
    }
    public void launchguesspage(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}
